-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 3.35.207.153    Database: moamoa
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project` (
  `project_no` bigint NOT NULL AUTO_INCREMENT,
  `project_category` varchar(255) NOT NULL,
  `project_contents` text,
  `project_cnt_apply` int NOT NULL DEFAULT '0',
  `project_create_date` date NOT NULL,
  `project_current_people` int NOT NULL DEFAULT '1',
  `project_end_date` date NOT NULL,
  `project_hit` int NOT NULL DEFAULT '0',
  `project_img` varchar(1000) DEFAULT NULL,
  `project_state` bit(1) NOT NULL DEFAULT b'0',
  `project_onoffline` varchar(255) NOT NULL,
  `project_start_date` date NOT NULL,
  `project_title` varchar(255) NOT NULL,
  `project_total_people` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`project_no`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` VALUES (81,'PROJECT','우리 같이 JavaScript와 TypeScript의 세계에 빠져봐요! 오프라인으로 매주 3일 모여서 공부한 내용 서로 공유하면서 같이 으쌰으쌰 힘내면 좋을 것 같아요!',4,'2023-02-14',1,'2023-02-22',164,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/project/TypeScript 완전 정복!!!!!',_binary '\0','OFFLINE','2023-02-15','TypeScript 완전 정복!!!!!',4),(83,'PROJECT','아아',0,'2023-02-14',1,'2023-02-18',34,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/engineering_team_yellow.png',_binary '','ONLINE','2023-02-14','연잔팀',6),(84,'STUDY','김영한님 강의로 진행할 생각입니다!',1,'2023-02-14',2,'2023-02-22',42,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/project/연잔팀2',_binary '\0','ONLINE','2023-02-14','JPA 뿌수기',3),(85,'STUDY','QueryDSL 을 마스터해봅시다.',1,'2023-02-14',2,'2023-02-24',71,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/project/%EA%B9%80%ED%8C%80%EC%9E%A5%EC%9D%98+QueryDSL+%EC%8A%A4%ED%84%B0%EB%94%94',_binary '\0','OFFLINE','2023-02-17','김팀장의 QueryDSL 스터디',7),(86,'PROJECT','재밌게 하실 분 구합니다. 꿀잼 보장',1,'2023-02-15',1,'2023-02-25',56,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/project/팀 다솔에서 팀원을 모집합니다(꿀잼)',_binary '\0','OFFLINE','2023-02-15','팀 다솔에서 팀원을 모집합니다(꿀잼)',6),(87,'STUDY','일주일에 3문제씩 풀고 인증하시면 됩니다!!\n다음주부터 시작할 예정입니다!!',1,'2023-02-15',2,'2023-02-17',57,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/project/알고리즘 스터디 같이 하실 분 모집합니다!!',_binary '\0','OFFLINE','2023-02-15','알고리즘팀',6),(89,'STUDY',NULL,0,'2023-02-15',1,'2023-03-01',2,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/purpleteam2.png',_binary '\0','ONLINE','2023-02-15','면접 대비 CS 스터디',4),(90,'STUDY',NULL,0,'2023-02-16',1,'2023-02-22',2,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/purpleteam1.png',_binary '\0','OFFLINE','2023-02-16','유온역 모각코해요',4),(91,'PROJECT','IT 업계 취업 준비생을 위한 앱을 만들고 싶습니다.',1,'2023-02-16',1,'2023-02-22',27,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/project/test.png',_binary '\0','ONLINE','2023-02-16','IT 취준생을 위한 앱??‍?',5),(92,'STUDY',NULL,0,'2023-02-16',1,'2023-02-22',10,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/yellowteam2.png',_binary '\0','ONLINE','2023-02-16','클린코드 완독?',3),(93,'PROJECT',NULL,0,'2023-02-16',1,'2023-02-22',9,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/yellowteam1.png',_binary '\0','ONLINE','2023-02-16','벌금 관리 서비스',7),(94,'PROJECT','세상의 모든 분리수거 방법을 알려드립니다,',0,'2023-02-16',1,'2023-02-22',12,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/blueteam1.png',_binary '\0','ONLINE','2023-02-16','쓰레기 백과사전 제작',4),(95,'STUDY',NULL,0,'2023-02-16',1,'2023-02-22',16,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/yellowteam1.png',_binary '\0','ONLINE','2023-02-16','JS 코테 1일 1문제 스터디',5),(96,'STUDY','자바를 잡아보자!',0,'2023-02-16',1,'2023-02-17',19,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/purpleteam2.png',_binary '\0','ONLINE','2023-02-16','자바를 자바',10),(97,'PROJECT','',0,'2023-02-16',1,'2023-02-17',13,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/blueteam2.png',_binary '\0','OFFLINE','2023-02-16','C언어 Study',2),(98,'PROJECT','CICD 가능한 프론트엔드 팀원 모집합니다!!!',1,'2023-02-16',0,'2023-02-28',25,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/purpleteam1.png',_binary '','ONLINE','2023-02-16','프론트 모집!!',6),(99,'STUDY','자바 마스터해봅시다!!\n스터디는 이펙티브 자바로 진행할 예정입니다!!!\n많은 지원 부탁드려요~!',0,'2023-02-16',1,'2023-02-19',10,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/yellowteam2.png',_binary '\0','ONLINE','2023-02-16','자바 마스터해요',3),(100,'STUDY','같이 기본부터 다질 사람을 찾습니다!',1,'2023-02-16',1,'2023-02-24',12,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/project/? 바닐라 JS 스터디',_binary '\0','OFFLINE','2023-02-16','? 바닐라 JS 스터디',4),(101,'PROJECT','백은 내가 할게 배포는 누가할래?',0,'2023-02-17',1,'2023-02-28',2,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/yellowteam2.png',_binary '\0','ONLINE','2023-02-17','배포팀',6),(102,'PROJECT','함께 하실분 모집해요! 부담없이 지원해주세요!',1,'2023-02-17',1,'2023-02-17',28,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/project/재활용의 모든 방법을 알려주는 프로젝트 제작해요',_binary '\0','ONLINE','2023-02-17','재활용 PJT',3),(103,'PROJECT','moa 프로젝트 만들어봅시다!',0,'2023-02-17',1,'2023-02-17',6,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/project/Moa',_binary '\0','ONLINE','2023-02-17','Moa',10),(104,'STUDY','개발 입문하는 햇병아리입니다. 파이썬이 제일 쉽다고 해서 공부해보려구요!',0,'2023-02-17',1,'2023-02-24',2,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/project/python 스터디하실 분',_binary '\0','ONLINE','2023-02-17','python 스터디하실 분',5),(105,'PROJECT','저희 플젝에선 어?금지입니다!',0,'2023-02-17',1,'2023-02-17',34,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/project/%EC%96%B4%3F+%EA%B8%88%EC%A7%80+PJT',_binary '\0','ONLINE','2023-02-17','어? 금지 PJT',6),(106,'PROJECT','백은 내가 할게 배포는 누가할래?',0,'2023-02-17',1,'2023-02-28',2,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/yellowteam2.png',_binary '','ONLINE','2023-02-17','배포팀',6);
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 10:24:30
