-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 3.35.207.153    Database: moamoa
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `profile_tech_stack`
--

DROP TABLE IF EXISTS `profile_tech_stack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profile_tech_stack` (
  `profile_stack_no` bigint NOT NULL AUTO_INCREMENT,
  `profile_tech_stack_order` int DEFAULT NULL,
  `profile_no` bigint NOT NULL,
  `tech_stack_no` bigint NOT NULL,
  PRIMARY KEY (`profile_stack_no`),
  KEY `FKqs5n0yffyj5jj59qfekx65xhm` (`profile_no`),
  KEY `FKhr614ljlwlqe3ptvbc1ixrudy` (`tech_stack_no`),
  CONSTRAINT `FKhr614ljlwlqe3ptvbc1ixrudy` FOREIGN KEY (`tech_stack_no`) REFERENCES `tech_stack` (`tech_stack_no`),
  CONSTRAINT `FKqs5n0yffyj5jj59qfekx65xhm` FOREIGN KEY (`profile_no`) REFERENCES `profile` (`profile_no`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_tech_stack`
--

LOCK TABLES `profile_tech_stack` WRITE;
/*!40000 ALTER TABLE `profile_tech_stack` DISABLE KEYS */;
INSERT INTO `profile_tech_stack` VALUES (27,1,25,19),(30,1,31,17),(31,2,31,19),(32,3,31,30),(33,4,31,28),(34,1,26,4),(35,2,26,11),(36,3,26,12),(37,1,36,4),(38,2,36,5),(39,3,36,1),(40,4,36,3),(44,1,30,5),(45,2,30,17),(46,3,30,19),(47,4,30,20),(48,1,27,4),(49,2,27,11),(50,3,27,24),(57,1,38,1),(58,2,38,2),(59,3,38,3),(60,4,38,4),(61,1,34,1),(62,2,34,4),(63,1,37,15),(64,2,37,25),(65,3,37,31),(66,4,37,27);
/*!40000 ALTER TABLE `profile_tech_stack` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 10:24:31
