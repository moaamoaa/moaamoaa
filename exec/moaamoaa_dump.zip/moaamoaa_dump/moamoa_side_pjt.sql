-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 3.35.207.153    Database: moamoa
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `side_pjt`
--

DROP TABLE IF EXISTS `side_pjt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `side_pjt` (
  `sidepjt_no` bigint NOT NULL AUTO_INCREMENT,
  `sidepjt_context` text,
  `sidepjt_name` varchar(255) NOT NULL,
  `sidepjt_year` varchar(255) DEFAULT NULL,
  `profile_no` bigint NOT NULL,
  PRIMARY KEY (`sidepjt_no`),
  KEY `FKlr7fa9efx1nupd3wsd6f3vj51` (`profile_no`),
  CONSTRAINT `FKlr7fa9efx1nupd3wsd6f3vj51` FOREIGN KEY (`profile_no`) REFERENCES `profile` (`profile_no`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `side_pjt`
--

LOCK TABLES `side_pjt` WRITE;
/*!40000 ALTER TABLE `side_pjt` DISABLE KEYS */;
INSERT INTO `side_pjt` VALUES (4,'최고의 팀 빌딩 서비스','모아모아','2023',25),(5,'영화 추천 서비스','포도당','2022',25),(6,'[2학기 공통 프로젝트] 최고의 팀 빌딩 서비스!','모아모아','2023',31),(7,'[1학기 관통 프로젝트] 영화 추천 서비스','포도당','2022',31),(8,'최고의 팀 빌딩 서비스 모아모아입니다','MoaaMoaa','2023',26),(9,'주택 거래 정보 제공 웹 사이트','LIVE','2022',26),(10,'기부런 챌린지 사이트','런투게더','2022',26),(11,'주니어 개발자들의 성장을 돕는 팀빌딩 서비스입니다.','모아모아 팀빌딩 서비스','2023',30),(12,'삼성청년소프트웨어아카데미 자바반 관통프로젝트','Where is my Home?','2022',27),(13,'Web-app based Second Hand Game Console Platform','LUDO','2021',27),(14,'Topic Modeling과 Semantic Network Analysis를 활용하여 COVID19 관련한 키워드로 떠오르는 주제들을 예측','COVID19 Related Analysis','2021',27),(15,'여행을 위한 기내 추천 서비스','MUTE','2022',38),(16,'팀빌딩 서비스','MOAAMOAA','2023',38);
/*!40000 ALTER TABLE `side_pjt` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 10:24:37
