-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 3.35.207.153    Database: moamoa
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `project_tech_stack`
--

DROP TABLE IF EXISTS `project_tech_stack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_tech_stack` (
  `project_stack_no` bigint NOT NULL AUTO_INCREMENT,
  `project_tech_stack_order` int DEFAULT NULL,
  `project_no` bigint NOT NULL,
  `tech_stack_no` bigint NOT NULL,
  PRIMARY KEY (`project_stack_no`),
  KEY `FK1j8ukk3bpevpyrmmkdpo8pfnx` (`project_no`),
  KEY `FKcdarkmg4jf8d1anip4vfppe1w` (`tech_stack_no`),
  CONSTRAINT `FK1j8ukk3bpevpyrmmkdpo8pfnx` FOREIGN KEY (`project_no`) REFERENCES `project` (`project_no`),
  CONSTRAINT `FKcdarkmg4jf8d1anip4vfppe1w` FOREIGN KEY (`tech_stack_no`) REFERENCES `tech_stack` (`tech_stack_no`)
) ENGINE=InnoDB AUTO_INCREMENT=368 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_tech_stack`
--

LOCK TABLES `project_tech_stack` WRITE;
/*!40000 ALTER TABLE `project_tech_stack` DISABLE KEYS */;
INSERT INTO `project_tech_stack` VALUES (165,1,83,4),(166,1,84,6),(167,2,84,5),(173,1,86,5),(174,2,86,4),(175,3,86,9),(176,4,86,17),(177,5,86,18),(178,6,86,19),(179,1,81,17),(180,2,81,18),(181,1,87,4),(182,2,87,5),(183,3,87,3),(187,1,96,4),(188,1,97,1),(189,1,98,29),(190,2,98,27),(191,1,99,4),(192,1,100,17),(233,1,101,29),(234,2,101,27),(235,1,94,4),(236,2,94,18),(349,1,102,4),(350,2,102,17),(351,3,102,19),(352,1,103,12),(353,2,103,27),(354,3,103,30),(355,4,103,31),(356,5,103,11),(357,6,103,4),(358,1,85,11),(359,2,85,4),(360,3,85,12),(361,1,104,5),(362,1,105,4),(363,2,105,11),(364,3,105,12),(365,4,105,14),(366,1,106,29),(367,2,106,27);
/*!40000 ALTER TABLE `project_tech_stack` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 10:24:32
