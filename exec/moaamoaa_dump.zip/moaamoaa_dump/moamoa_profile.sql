-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 3.35.207.153    Database: moamoa
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profile` (
  `profile_no` bigint NOT NULL AUTO_INCREMENT,
  `profile_context` text,
  `profile_cnt_offer` int DEFAULT '0',
  `profile_hit` int DEFAULT '0',
  `profile_img` varchar(255) DEFAULT NULL,
  `profile_nickname` varchar(255) NOT NULL,
  `profile_on_off_status` varchar(255) NOT NULL DEFAULT 'ONLINE',
  `search_state` varchar(255) NOT NULL DEFAULT 'ALL',
  `user_no` bigint NOT NULL,
  PRIMARY KEY (`profile_no`),
  KEY `FKftye0s2u0gqnh7a1ad88hbvud` (`user_no`),
  CONSTRAINT `FKftye0s2u0gqnh7a1ad88hbvud` FOREIGN KEY (`user_no`) REFERENCES `user` (`user_no`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (24,NULL,0,125,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/profile/jiji','jiji','ALL','ALL',24),(25,'안녕하세요. 프론트엔드 개발자 임성빈입니다. 잘부탁 드립니다!',0,101,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/profile/임성빈','임성빈','ALL','NONE',25),(26,'안녕하세요\n백엔드 자바 스프링 공부 중입니다!!!',3,239,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/profile/연잔','연잔','ALL','ALL',26),(27,'안녕하세요 열정 백엔드 개발자입니다 ',0,96,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/profile/김동동','김동동','OFFLINE','ALL',27),(28,NULL,0,25,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/yellow_cat.png','구스','ONLINE','ALL',28),(29,NULL,0,11,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/yellow_cat.png','나강림','ONLINE','ALL',29),(30,'안녕하세요. 꾸준히 성장하는 개발자를 꿈꾸는 황다솔입니다. 잘부탁드려요! 모아모아 너무 편하고 좋네요',0,28,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/profile/황다솔','황다솔','ONLINE','PROJECT',30),(31,'안녕하세요^^\n프론트엔드이지만 배포도 자신있는 개발자 임성빈입니다.\n성실히 프로젝트에 참여하겠습니다.',3,35,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/profile/임성빈','임성빈','ALL','PROJECT',31),(32,NULL,0,12,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/blue_cat.png','할수있다능','ONLINE','ALL',32),(33,NULL,0,5,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/yellow_dog.png','혜쮸','ONLINE','PROJECT',33),(34,NULL,1,16,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/profile/람쥐?','람쥐?','ALL','ALL',34),(35,NULL,0,3,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/default/yellow_cat.png','흠뭐하지여기서','ONLINE','ALL',35),(36,'안녕하세요. 저희집 고양이 귀엽죠?',0,4,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/profile/우리집고양이밍이','우리집고양이밍이','ONLINE','ALL',36),(37,'나는 알고리즘을 좋아하는 고양이!',0,8,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/profile/알고고앵','알고고앵','ONLINE','ALL',37),(38,'유하하이! 저랑 프로젝트 하실 분~ 제안 보내주세요오오오오!!!! 화이티이이잉',0,14,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/profile/유하하이','유하하이','ONLINE','ALL',38);
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 10:24:38
