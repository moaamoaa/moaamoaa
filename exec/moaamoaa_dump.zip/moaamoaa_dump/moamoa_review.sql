-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 3.35.207.153    Database: moamoa
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `review_no` bigint NOT NULL AUTO_INCREMENT,
  `review_context` text NOT NULL,
  `review_time` timestamp NOT NULL,
  `review_receive` bigint NOT NULL,
  `review_send` bigint NOT NULL,
  PRIMARY KEY (`review_no`),
  KEY `FKhh92g1sk38vhfn7u86broue9g` (`review_receive`),
  KEY `FKmjqyqufmfsfam8e9o0sqiol59` (`review_send`),
  CONSTRAINT `FKhh92g1sk38vhfn7u86broue9g` FOREIGN KEY (`review_receive`) REFERENCES `profile` (`profile_no`),
  CONSTRAINT `FKmjqyqufmfsfam8e9o0sqiol59` FOREIGN KEY (`review_send`) REFERENCES `profile` (`profile_no`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (1,'안녕하세요','2023-02-14 04:33:23',24,25),(10,'스ㅡ','2023-02-14 05:37:09',25,27),(12,'누구세요?','2023-02-14 09:06:59',28,25),(13,'역시 팀장','2023-02-14 09:07:14',27,25),(14,'연잔 나도 깃허브 팔로우해줘요','2023-02-14 09:07:34',26,25),(15,'누구시죠???','2023-02-14 23:47:16',28,26),(16,'hi ?','2023-02-16 00:12:50',25,24),(17,'댓글 좀 많이 달아줘요~','2023-02-16 05:35:50',25,25),(18,'안녕!!!!!','2023-02-16 08:52:44',26,33),(23,'알고리즘 스터디 같이 하실래요?!','2023-02-16 16:06:01',24,26),(24,'모아모아 같이 완성하느라 수고 많으셨습니다!','2023-02-16 16:46:48',30,31),(25,'공통에 이어서 특화 프로젝트도 같이하는데 잘 부탁드립니다!','2023-02-16 23:53:21',34,31),(27,'성빈님 수고 많으셨습니다. 진짜 프엔신이에요!! 여러분 이분 데려가셔야 합니다.','2023-02-17 00:21:55',31,30),(28,'다솔님 영상편집 능려자십니다!!','2023-02-17 00:26:14',30,26),(29,'열정 백엔드 개발자 동동 팀장님','2023-02-17 00:27:26',27,26),(30,'저의 프로필에 오신 것을 환영합니다.','2023-02-17 00:29:33',38,38),(31,'열정맨 그 잡채!!!','2023-02-17 00:31:08',31,34),(32,'성빈님 완전 능력자 ','2023-02-17 00:31:31',31,38),(33,'역시 백장님 정말 멋져요 우와','2023-02-17 00:31:40',26,27),(34,'야옹','2023-02-17 00:34:50',37,37),(35,'배포 장인 람쥐람쥐연','2023-02-17 00:35:46',34,27),(36,'프론트 마스터 유하님!!','2023-02-17 00:36:11',38,27);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 10:24:38
