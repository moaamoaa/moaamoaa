-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 3.35.207.153    Database: moamoa
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_no` bigint NOT NULL AUTO_INCREMENT,
  `user_email` varchar(255) NOT NULL,
  `user_state` bit(1) NOT NULL DEFAULT b'0',
  `user_join_date` date NOT NULL,
  `user_pwd` varchar(255) NOT NULL,
  `user_refresh_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_no`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (24,'jiyeonyou0416@naver.com',_binary '\0','2023-02-14','$2a$10$PcwEjAY3/Y99E5wGUTMP8Om/RA7lc.QaKdFDeNi6JompfhX5K/nze','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyZWZyZXNoLXRva2VuIiwiaWF0IjoxNjc2NTkzMzEzLCJleHAiOjE2Nzc4MDI5MTN9.Wtr6rIUbHD3mX75mvsGd7I21UX82d74OFR_SuxDRmlM'),(25,'dtq03087@gmail.com',_binary '\0','2023-02-14','$2a$10$gHtJfQuywI0k4AStxaaf5OrVb5Cluw4yT6EGNyVY4yxyHOv1XHzFu','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyZWZyZXNoLXRva2VuIiwiaWF0IjoxNjc2NTU5NDQ4LCJleHAiOjE2Nzc3NjkwNDh9.DM1muEHH1iPsioXefeLBVpZX6dOZgp3iH38_jQMIQNg'),(26,'y_jin99@naver.com',_binary '\0','2023-02-14','$2a$10$Es4fMvo0OtzScCHqw0Hw1uyoIN2mA7OO/MHMO7.dLuH0c0z6Q4wC2','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyZWZyZXNoLXRva2VuIiwiaWF0IjoxNjc2NTk3MDAzLCJleHAiOjE2Nzc4MDY2MDN9.lE22nIVKm7yavWpHGfmVxFwH8Nal3Xx-JI7dF8kcs7U'),(27,'smartpodo@kakao.com',_binary '\0','2023-02-14','$2a$10$JU5j1bEdYPoDnCLnGT5I5OzrjRSMFEfuyiVAC0hFENgHVA3Co8dSW','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyZWZyZXNoLXRva2VuIiwiaWF0IjoxNjc2NTkyNDQ1LCJleHAiOjE2Nzc4MDIwNDV9.gDTn8zFrObZqQOpLLYVzp--0M-FZPNqcaWeSYJy_8pY'),(28,'gusrnqq@naver.com',_binary '\0','2023-02-14','$2a$10$6uPsyjHmHT2wsfkZVRng4.cy2/4ogONCVqAGibIbby5HD.Zb8Biz.','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyZWZyZXNoLXRva2VuIiwiaWF0IjoxNjc2MzU4ODEyLCJleHAiOjE2Nzc1Njg0MTJ9.GRWcbPcWSW6jdBJVqkGRf2APXkGXf5Gps2RrpHpm_dc'),(29,'wlghks960@naver.com',_binary '\0','2023-02-15','$2a$10$Q2xR5jGGq/kTqgypEm.zjOKhKUMIYgYPo.s1/6aysomuRUqjoXgjG','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyZWZyZXNoLXRva2VuIiwiaWF0IjoxNjc2NDM3MzQyLCJleHAiOjE2Nzc2NDY5NDJ9.QIqK6CJu-OMU8VR5kwcLHovG1GCvJIohaLN6Zz-rNEo'),(30,'pinetree-1017@naver.com',_binary '\0','2023-02-15','$2a$10$a9lrgfcQEoOFxIKYvfYoOO1HQe8MDtNymvgeKLZv02475XKEjH7Ku','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyZWZyZXNoLXRva2VuIiwiaWF0IjoxNjc2NTk1MTUxLCJleHAiOjE2Nzc4MDQ3NTF9.Qs-8Jj-HfKZ48PVs8EAFXoQKU-I4qNfCB7uz2Hzc-LY'),(31,'mae03087@naver.com',_binary '\0','2023-02-15','$2a$10$/Ei1fEL/.AZMLfzCRWuXMu8Y9.FfgGHkHSlDwXEEYzhaI/sEzmwIO','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyZWZyZXNoLXRva2VuIiwiaWF0IjoxNjc2NTkzNjA4LCJleHAiOjE2Nzc4MDMyMDh9.Wio9cTiRFzRDDe_tM-gsEU9WjQoBo2W2l_u6zMy0JKE'),(32,'ssafy.only@gmail.com',_binary '\0','2023-02-16','$2a$10$qU11VrTUTTc2BCC1uzy69uVbUcFbmk9p779k3Q34njdb6WTH14TdO','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyZWZyZXNoLXRva2VuIiwiaWF0IjoxNjc2NTI5NzgxLCJleHAiOjE2Nzc3MzkzODF9.5bMWDqgiQqGO-T_Kjv4c7k_gIw1tApsJ_cFkkD_kOaE'),(33,'fixup719@gmail.com',_binary '\0','2023-02-16','$2a$10$mi.EXHO2WFXjb9QAVBVoFOvPXhV3DexM/KJXy.cZn/xmCRnLyxV9.','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyZWZyZXNoLXRva2VuIiwiaWF0IjoxNjc2NTM3NTI1LCJleHAiOjE2Nzc3NDcxMjV9.mVJITwCj_R487z98IHMwKG_cXg-mxZuaddOpAwRcFEg'),(34,'jiyeon416@nate.com',_binary '\0','2023-02-16','$2a$10$nDhfT8PTenBb/Qq0F3XIBOR98HPxjYR5S5BvrXm.dO7TS65kXM45W',NULL),(35,'spirits1232@gmail.com',_binary '','2023-02-16','$2a$10$44qLODq7eV4K8vz3b5epZO/KbVDsI.gHjUkj3M9k/CZPkWZ9neu96','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyZWZyZXNoLXRva2VuIiwiaWF0IjoxNjc2NTYzMDczLCJleHAiOjE2Nzc3NzI2NzN9.dmdIf1CDTh7hBQ9zy8usAt57X1W6WjH3SqfHX8UDXK4'),(36,'yeonjin5381@daum.net',_binary '\0','2023-02-16','$2a$10$DDkHyyGA4iZRwx0mMK9rx.V78byA6AItjTQPKfoy8u84QUpqGeTYq','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyZWZyZXNoLXRva2VuIiwiaWF0IjoxNjc2NTg5ODEzLCJleHAiOjE2Nzc3OTk0MTN9.f7CgDDK5tJflC1RH0-idZbFyHLIfvLfpwQ3jxzY47EI'),(37,'jyuha759@gmail.com',_binary '\0','2023-02-16','$2a$10$hrN0RdWZqjN3EtdCKvaFEeo6DDJ7JjY4.M9BHMNO6O4GIDKj4oZ..','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyZWZyZXNoLXRva2VuIiwiaWF0IjoxNjc2NTk0MDE3LCJleHAiOjE2Nzc4MDM2MTd9.5aWtiMIJzDkK_IprEay4zubWamiS7kNVhmgPNp0uMQ0'),(38,'scs0303@naver.com',_binary '\0','2023-02-17','$2a$10$MzOpUuZ2qgZvEWQUqUCXr.rrdDGc0/SOJnenNod.OQG3EQZrRIUjC',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 10:24:32
