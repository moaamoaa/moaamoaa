-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 3.35.207.153    Database: moamoa
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tech_stack`
--

DROP TABLE IF EXISTS `tech_stack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tech_stack` (
  `tech_stack_no` bigint NOT NULL AUTO_INCREMENT,
  `tech_stack_logo` varchar(255) DEFAULT NULL,
  `tech_stack_name` varchar(255) NOT NULL,
  PRIMARY KEY (`tech_stack_no`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tech_stack`
--

LOCK TABLES `tech_stack` WRITE;
/*!40000 ALTER TABLE `tech_stack` DISABLE KEYS */;
INSERT INTO `tech_stack` VALUES (1,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/c.png','C'),(2,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/csharp.png','C#'),(3,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/cpp.png','C++'),(4,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/java.png','Java'),(5,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/python.png','Python'),(6,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/kotlin.png','Kotlin'),(7,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/go.png','Go'),(8,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/nestjs.png','Nest.js'),(9,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/nodejs.png','Node.js'),(10,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/django.png','Django'),(11,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/spring.png','Spring'),(12,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/mysql.png','MySQL'),(13,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/graphql.png','GraphQL'),(14,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/redis.png','Redis'),(15,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/mongodb.png','MongoDB'),(16,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/firebase.png','Firebase'),(17,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/javascript.png','Javascript'),(18,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/typescript.png','Typescript'),(19,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/react.png','React'),(20,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/vue.png','Vue'),(21,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/angular.png','Angular'),(22,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/svelte.png','Svelte'),(23,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/nextjs.png','Next.js'),(24,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/swift.png','Swift'),(25,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/swiftui.png','SwiftUI'),(26,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/flutter.png','Flutter'),(27,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/aws.png','AWS'),(28,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/docker.png','Docker'),(29,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/kubernetes.png','Kubernetes'),(30,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/jenkins.png','Jenkins'),(31,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/figma.png','Figma'),(32,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/git.png','Git'),(33,'https://s3.ap-northeast-2.amazonaws.com/ssafy.moamoa.image.bucket/techstacks/unity.png','Unity');
/*!40000 ALTER TABLE `tech_stack` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 10:24:36
