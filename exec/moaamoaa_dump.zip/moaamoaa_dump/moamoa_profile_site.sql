-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 3.35.207.153    Database: moamoa
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `profile_site`
--

DROP TABLE IF EXISTS `profile_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profile_site` (
  `profilesite_no` bigint NOT NULL AUTO_INCREMENT,
  `profilesite_link` varchar(255) DEFAULT NULL,
  `profile_no` bigint NOT NULL,
  `site_no` bigint NOT NULL,
  PRIMARY KEY (`profilesite_no`),
  KEY `FKav0jafulxspmw46se4fnmmbum` (`profile_no`),
  KEY `FK672jcvqsejmhayvgjaaubygte` (`site_no`),
  CONSTRAINT `FK672jcvqsejmhayvgjaaubygte` FOREIGN KEY (`site_no`) REFERENCES `site` (`site_no`),
  CONSTRAINT `FKav0jafulxspmw46se4fnmmbum` FOREIGN KEY (`profile_no`) REFERENCES `profile` (`profile_no`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_site`
--

LOCK TABLES `profile_site` WRITE;
/*!40000 ALTER TABLE `profile_site` DISABLE KEYS */;
INSERT INTO `profile_site` VALUES (5,'https://github.com/LimSB-dev',25,1),(6,'https://github.com/LimSB-dev',25,2),(7,'https://github.com/LimSB-dev',25,3),(8,'https://github.com/LimSB-dev',25,4),(17,'',24,1),(18,'',24,2),(19,'',24,3),(20,'',24,4),(29,'https://github.com/LimSB-dev',31,1),(30,'',31,2),(31,'https://velog.io/',31,3),(32,'',31,4),(33,'https://github.com/yeonjan',26,1),(34,'https://yjin99.tistory.com/',26,2),(35,'',26,3),(36,'',26,4),(37,'',36,1),(38,'',36,2),(39,'',36,3),(40,'',36,4),(45,'',30,1),(46,'',30,2),(47,'',30,3),(48,'',30,4),(49,'www.github.com',27,1),(50,'www.tistory.com',27,2),(51,'https://velog.io/@smartpodo',27,3),(52,'www.moaamoaaa.com',27,4),(61,'https://moaamoaa.com/ProfileEditPage',38,1),(62,'https://moaamoaa.com/ProfileEditPage',38,2),(63,'https://moaamoaa.com/ProfileEditPage',38,3),(64,'https://moaamoaa.com/ProfileEditPage',38,4),(65,'https://github.com/youjiyeon',34,1),(66,'',34,2),(67,'',34,3),(68,'',34,4),(69,'https://moaamoaa.com/ProfileEditPage',37,1),(70,'https://moaamoaa.com/ProfileEditPage',37,2),(71,'https://moaamoaa.com/ProfileEditPage',37,3),(72,'https://moaamoaa.com/ProfileEditPage',37,4);
/*!40000 ALTER TABLE `profile_site` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 10:24:35
